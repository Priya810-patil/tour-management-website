
export default function CarouselCheckListData({data}){
    return(
        <div>
            {data}
            </div>
           )
    }