

// import React from 'react';
import SearchCondition from './SearchCondition';

// const App = () => {
//   // You can change the condition to see different messages
//   const condition = 'B';

//   return (
//     <div>
//       <h1>Conditional Rendering Example</h1>
//       <ConditionalRenderingExample condition={condition} />
//     </div>
//   );
// };

// export default App;



export default function SearchFormMain(){
    return<SearchCondition/>
}