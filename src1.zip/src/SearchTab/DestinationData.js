
const Destination=[
      {
        id:9,
        name:"Destination"
    },  
{
    id:1,
    name:"Kerala"
    
},
{
    id:2,
    name:"Shimala"
},
{
    id:3,
    name:"Himachal"
},
{
    id:4,
    name:"Andanman"
},
{
    id:5,
    name:"Thailand"
},
{
    id:6,
    name:"Uttarakhan"
},
{
    id:7,
    name:"Goa"
},
{
    id:8,
    name:"Rajasthan"
}
];

export default Destination;