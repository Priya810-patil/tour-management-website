import SearchMainRoute from "./SearchMainRoute";
import './App.css'
import Carouselnew from "./BestSellingPacakage/Carouselnew";
import SearchFormMain from "./SearchTab/SearchFormMain";
import KeralaList from "./Explore/KeralaList";
import PaymentPage from "./Payment/PaymentPage";

function App() {
  return (
    <div>
     {/* <SearchMainRoute />  */}
      <Carouselnew />
      {/* <KeralaList /> */}
      <PaymentPage/>
    </div>
  )
}


export default App;