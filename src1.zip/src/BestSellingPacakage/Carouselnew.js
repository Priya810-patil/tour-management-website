import React, { useEffect, useState } from "react";
import "./Carouselnew.css";
import Carousel from "react-multi-carousel";
import "react-multi-carousel/lib/styles.css";
import { carouseldata, responsive } from "./CarouselData";
import CarouselItem from "./CarouselItem.js";
import { useForceUpdate } from "../commonFunction/Function";

let product = carouseldata

export default function Carouselnew() {
  const forceUpdate = useForceUpdate();


  const [dest, setDest] = useState(carouseldata);

  // useEffect(() => {
  //   product = carouseldata.map((item) => (
  //     <CarouselItem name={item.name} url={item.imageurl} />

  //   ));
  //   setDest(product)
  // })


  // const handleDestinationChange = (e) =>{
  //   setDest(e.target.checked)
  //   console.log(dest)
  // }

  // const desListItem = carouseldata.map((E) => {
  //   return E.isNational ?
  //     <CarouselItem type={E.type} name={E.name} url={E.imageurl} National='YES' /> :
  //     <CarouselItem type={E.type} name={E.name} url={E.imageurl} National='NO' />
  // }
  // )

  const handleDestinationChangenew = (destnat) => {
    console.log(destnat)

    dest.filter((destnt) => {
      console.log(destnt.type)
      if (destnt.type === destnat) {
        console.log('jhshs')
        return destnt;

      }
    })
    console.log(dest, 'hiiiiii')
    forceUpdate()
    };


  console.log(dest, 'hjnnimk')
  const cardest = () => (
    dest.map((item) => (

      <CarouselItem name={item.name} url={item.imageurl} />
    ))
  )


  return (
    <div className="container">
      <div className="carousel">
        <h3 className="headcarousel"
          style={{ textAlign: "center", color: "red" }}>Best Selling Holiday Pacakage</h3>
        <div style={{ alignItems: "center" }} className="checkformmain">
          <div class="form-check form-check-inline">
            <input class="form-check-input" type="radio" name="destination" onChange={(e) => handleDestinationChangenew(e.target.checked, 'International')} id="inlineCheckbox1" value="International" />
            <label class="form-check-label" for="inlineCheckbox1">Internation Destination</label>
          </div>
          <div class="form-check form-check-inline">
            <input class="form-check-input" type="radio" name="destination" onChange={(e) => handleDestinationChangenew(e.target.checked, 'India')} id="inlineCheckbox2" value="India" />
            <label class="form-check-label" for="inlineCheckbox2">Destination within India</label>
          </div>
        </div>
        {/* <Carousel responsive={responsive}>{product}</Carousel> */}

        {
          cardest()
        }

      </div >
    </div>
  );
}
